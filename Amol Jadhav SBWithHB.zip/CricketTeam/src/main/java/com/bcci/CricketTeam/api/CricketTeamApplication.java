package com.bcci.CricketTeam.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//Amol Rajput
@SpringBootApplication
public class CricketTeamApplication {

	public static void main(String[] args) {
		SpringApplication.run(CricketTeamApplication.class, args);
	}

}
