package com.bcci.CricketTeam.api.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.bcci.CricketTeam.api.Service.Dao.TeamDao;
import com.bcci.CricketTeam.api.Service.Entity.Team;

@Service
public class TeamService {
	@Autowired
	TeamDao td;

	public List<Team> getAllPlayer() {
	return	td.getAllPlayer();
	}

	public Team getplyaerbyid(int pno) {
		return td.getplyaerbyid(pno);
		
	}

	public String insertplayer(Team team) {
	String string=	td.insertplayer(team);
	return string;
	}

	public String deleteplayer(int pno) {
		String string= td.deleteplayer(pno);
		
		return string;
	}

	public String updateplayer(Team team) {
		String string=	td.updateplayer(team);
		return string;
	}
	

}
