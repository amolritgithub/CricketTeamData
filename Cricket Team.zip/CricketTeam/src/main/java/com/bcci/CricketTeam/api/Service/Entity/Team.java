package com.bcci.CricketTeam.api.Service.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Team {
	
   @Id
   private int pno;
   private String pname;
   private int age;
   private long phoneno;
   
public Team() {
	super();
	// TODO Auto-generated constructor stub
}
public Team(int pno, String pname, int age, long phoneno) {
	super();
	this.pno = pno;
	this.pname = pname;
	this.age = age;
	this.phoneno = phoneno;
}
public int getPno() {
	return pno;
}
public void setPno(int pno) {
	this.pno = pno;
}
public String getPname() {
	return pname;
}
public void setPname(String pname) {
	this.pname = pname;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public long getPhoneno() {
	return phoneno;
}
public void setPhoneno(long phoneno) {
	this.phoneno = phoneno;
}
@Override
public String toString() {
	return "Team [pno=" + pno + ", pname=" + pname + ", age=" + age + ", phoneno=" + phoneno + "]";
}
   
   
   
	

}
