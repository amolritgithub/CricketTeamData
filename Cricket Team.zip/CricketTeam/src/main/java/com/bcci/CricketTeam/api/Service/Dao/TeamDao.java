package com.bcci.CricketTeam.api.Service.Dao;

import java.util.List;


import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bcci.CricketTeam.api.Service.Entity.Team;

@Repository
public class TeamDao {
	@Autowired
	SessionFactory sf;

	public List<Team> getAllPlayer() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Team.class);
		List<Team> list = criteria.list();
		session.close();
		return list;
	}

	public Team getplyaerbyid(int pno) {
		Session session = sf.openSession();
		Team player = session.get(Team.class, pno);
		session.close();
		return player;
	}

	public String insertplayer(Team team) {
		Session session= sf.openSession();
		Transaction tx = session.beginTransaction();
		session.save(team);
		tx.commit();
		
		session.close();
		return "Data Insert SuccessFully";
	}

	public String deleteplayer(int pno) {
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		Team player = session.get(Team.class, pno);
		session.delete(player);
		tx.commit();
		session.close();
		
		return "Data Delete Sucessfully";
	}

	public String updateplayer(Team team) {
		Session session= sf.openSession();
		Transaction tx = session.beginTransaction();
		session.update(team);
		tx.commit();
		session.close();
		return "Data update SuccessFully";
	}

}
