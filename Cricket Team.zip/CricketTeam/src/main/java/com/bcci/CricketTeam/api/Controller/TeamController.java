package com.bcci.CricketTeam.api.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bcci.CricketTeam.api.Service.TeamService;
import com.bcci.CricketTeam.api.Service.Entity.Team;

@RestController
@RequestMapping("/api")
@CrossOrigin("http://localhost:8080")
public class TeamController {
	
	@Autowired
	TeamService ts;
	
	
	@GetMapping("/all")
	public List<Team> getAllPlayer(){
		List<Team> list	=ts.getAllPlayer();
		return list;
	}
	
	@GetMapping("player/{pno}")
	public Team getplyaerbyid(@PathVariable int pno)
	{
		Team player = ts.getplyaerbyid(pno);
		return player;
	}
	
	@PostMapping("/add")
	public String insertplayer(@RequestBody Team team)
	{
		String string= ts.insertplayer(team);
		return string;
	}
	
	@DeleteMapping("/delete/{pno}")
	public String deleteplayer(@PathVariable int pno)
	{
		String string= ts.deleteplayer(pno);
		return string;
	}
	
	@PutMapping("/update")
	public String updateplayer(@RequestBody Team team)
	{
		String string= ts.updateplayer(team);
		return string;
	}

}
