package com.bcci.CricketTeam.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
//Amol Rajput
@SpringBootApplication
@ComponentScan("com")
public class CricketTeamApplication {

	public static void main(String[] args) {
		SpringApplication.run(CricketTeamApplication.class, args);
	}

}
